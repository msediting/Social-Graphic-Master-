import {
  Template,
  InsertTemplate,
  Design,
  InsertDesign,
  ABTest,
  InsertABTest,
  TestResult,
  InsertTestResult
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // Template operations
  getAllTemplates(): Promise<Template[]>;
  getTemplate(id: number): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;

  // Design operations
  getAllDesigns(): Promise<Design[]>;
  getDesign(id: number): Promise<Design | undefined>;
  createDesign(design: InsertDesign): Promise<Design>;
  updateDesign(id: number, design: InsertDesign): Promise<Design | undefined>;

  // A/B Test operations
  getAllABTests(): Promise<ABTest[]>;
  getABTest(id: number): Promise<ABTest | undefined>;
  createABTest(test: InsertABTest): Promise<ABTest>;
  updateABTestStatus(id: number, status: string): Promise<ABTest | undefined>;

  // Test Results operations
  getTestResults(testId: number): Promise<TestResult | undefined>;
  updateTestResults(results: InsertTestResult): Promise<TestResult>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private templates: Map<number, Template>;
  private designs: Map<number, Design>;
  private abTests: Map<number, ABTest>;
  private testResults: Map<number, TestResult>;
  
  private templateId: number;
  private designId: number;
  private abTestId: number;
  private resultId: number;

  constructor() {
    this.templates = new Map();
    this.designs = new Map();
    this.abTests = new Map();
    this.testResults = new Map();
    
    this.templateId = 1;
    this.designId = 1;
    this.abTestId = 1;
    this.resultId = 1;
    
    // Initialize with sample templates
    this.seedTemplates();
  }

  // Template operations
  async getAllTemplates(): Promise<Template[]> {
    return Array.from(this.templates.values());
  }

  async getTemplate(id: number): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const id = this.templateId++;
    const newTemplate: Template = { ...template, id };
    this.templates.set(id, newTemplate);
    return newTemplate;
  }

  // Design operations
  async getAllDesigns(): Promise<Design[]> {
    return Array.from(this.designs.values());
  }

  async getDesign(id: number): Promise<Design | undefined> {
    return this.designs.get(id);
  }

  async createDesign(design: InsertDesign): Promise<Design> {
    const id = this.designId++;
    const newDesign: Design = { 
      ...design, 
      id, 
      createdAt: new Date() 
    };
    this.designs.set(id, newDesign);
    return newDesign;
  }

  async updateDesign(id: number, design: InsertDesign): Promise<Design | undefined> {
    const existingDesign = this.designs.get(id);
    if (!existingDesign) return undefined;
    
    const updatedDesign: Design = {
      ...existingDesign,
      name: design.name,
      canvasData: design.canvasData,
      width: design.width,
      height: design.height
    };
    this.designs.set(id, updatedDesign);
    return updatedDesign;
  }

  // A/B Test operations
  async getAllABTests(): Promise<ABTest[]> {
    return Array.from(this.abTests.values());
  }

  async getABTest(id: number): Promise<ABTest | undefined> {
    return this.abTests.get(id);
  }

  async createABTest(test: InsertABTest): Promise<ABTest> {
    const id = this.abTestId++;
    const newTest: ABTest = {
      ...test,
      id,
      createdAt: new Date()
    };
    this.abTests.set(id, newTest);
    
    // Create initial test results
    await this.updateTestResults({
      testId: id,
      impressionsA: 0,
      impressionsB: 0,
      clicksA: 0,
      clicksB: 0,
      conversionsA: 0,
      conversionsB: 0
    });
    
    return newTest;
  }

  async updateABTestStatus(id: number, status: string): Promise<ABTest | undefined> {
    const existingTest = this.abTests.get(id);
    if (!existingTest) return undefined;
    
    const updatedTest: ABTest = {
      ...existingTest,
      status
    };
    this.abTests.set(id, updatedTest);
    return updatedTest;
  }

  // Test Results operations
  async getTestResults(testId: number): Promise<TestResult | undefined> {
    return Array.from(this.testResults.values()).find(
      (result) => result.testId === testId
    );
  }

  async updateTestResults(results: InsertTestResult): Promise<TestResult> {
    const existingResult = await this.getTestResults(results.testId);
    
    if (existingResult) {
      const updatedResult: TestResult = {
        ...existingResult,
        impressionsA: results.impressionsA,
        impressionsB: results.impressionsB,
        clicksA: results.clicksA,
        clicksB: results.clicksB,
        conversionsA: results.conversionsA,
        conversionsB: results.conversionsB,
        updatedAt: new Date()
      };
      this.testResults.set(existingResult.id, updatedResult);
      return updatedResult;
    } else {
      const id = this.resultId++;
      const newResult: TestResult = {
        ...results,
        id,
        updatedAt: new Date()
      };
      this.testResults.set(id, newResult);
      return newResult;
    }
  }

  // Seed method to initialize templates
  private seedTemplates() {
    const templates: InsertTemplate[] = [
      {
        name: "Instagram Post",
        description: "Square template for Instagram posts",
        width: 1080,
        height: 1080,
        category: "instagram",
        thumbnail: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7",
        canvasData: {
          background: {
            type: "gradient",
            colors: ["#6366F1", "#8B5CF6", "#EC4899"],
            direction: "to-br"
          },
          objects: []
        }
      },
      {
        name: "Twitter Post",
        description: "Landscape template for Twitter posts",
        width: 1200,
        height: 675,
        category: "twitter",
        thumbnail: "https://images.unsplash.com/photo-1611162616475-46b635cb6868",
        canvasData: {
          background: {
            type: "solid",
            color: "#F9FAFB"
          },
          objects: []
        }
      },
      {
        name: "Facebook Post",
        description: "Template for Facebook posts",
        width: 1200,
        height: 630,
        category: "facebook",
        thumbnail: "https://images.unsplash.com/photo-1563986768609-322da13575f3",
        canvasData: {
          background: {
            type: "solid",
            color: "#FFFFFF"
          },
          objects: []
        }
      },
      {
        name: "LinkedIn Post",
        description: "Professional template for LinkedIn",
        width: 1200,
        height: 627,
        category: "linkedin",
        thumbnail: "https://images.unsplash.com/photo-1551135049-8a33b5883817",
        canvasData: {
          background: {
            type: "solid",
            color: "#F3F4F6"
          },
          objects: []
        }
      },
      {
        name: "Instagram Story",
        description: "Vertical template for Instagram stories",
        width: 1080,
        height: 1920,
        category: "instagram",
        thumbnail: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853",
        canvasData: {
          background: {
            type: "solid",
            color: "#F9FAFB"
          },
          objects: []
        }
      },
      {
        name: "Pinterest Pin",
        description: "Vertical template for Pinterest pins",
        width: 1000,
        height: 1500,
        category: "pinterest",
        thumbnail: "https://images.unsplash.com/photo-1483058712412-4245e9b90334",
        canvasData: {
          background: {
            type: "solid",
            color: "#FFFFFF"
          },
          objects: []
        }
      },
      {
        name: "YouTube Thumbnail",
        description: "Thumbnail for YouTube videos",
        width: 1280,
        height: 720,
        category: "youtube",
        thumbnail: "https://images.unsplash.com/photo-1593642702821-c8da6771f0c6",
        canvasData: {
          background: {
            type: "solid",
            color: "#FFFFFF"
          },
          objects: []
        }
      },
      {
        name: "YouTube Banner",
        description: "Banner for YouTube channels",
        width: 2560,
        height: 1440,
        category: "youtube",
        thumbnail: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0",
        canvasData: {
          background: {
            type: "solid",
            color: "#F9FAFB"
          },
          objects: []
        }
      },
      {
        name: "Ad Banner",
        description: "Banner for online advertisements",
        width: 1200,
        height: 628,
        category: "ads",
        thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f",
        canvasData: {
          background: {
            type: "solid",
            color: "#F9FAFB"
          },
          objects: []
        }
      },
      {
        name: "Campaign Banner",
        description: "Square banner for marketing campaigns",
        width: 1080,
        height: 1080,
        category: "ads",
        thumbnail: "https://pixabay.com/get/g9cb6e9a4796dfb1f4388088557ab2ebcc2d6eee9ac09afad6832839013de6da220f668374dc9051a3fdc1edf94df79d36e8d12f6b312306b13778959af327a49_1280.jpg",
        canvasData: {
          background: {
            type: "solid",
            color: "#FFFFFF"
          },
          objects: []
        }
      }
    ];

    templates.forEach(template => {
      this.createTemplate(template);
    });
  }
}

export const storage = new MemStorage();
