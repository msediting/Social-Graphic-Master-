import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTemplateSchema, insertDesignSchema, insertABTestSchema, insertTestResultsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Templates endpoints
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getAllTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  app.get("/api/templates/:id", async (req, res) => {
    try {
      const template = await storage.getTemplate(Number(req.params.id));
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch template" });
    }
  });

  app.post("/api/templates", async (req, res) => {
    try {
      const validatedData = insertTemplateSchema.parse(req.body);
      const template = await storage.createTemplate(validatedData);
      res.status(201).json(template);
    } catch (error) {
      res.status(400).json({ message: "Invalid template data" });
    }
  });

  // Designs endpoints
  app.get("/api/designs", async (req, res) => {
    try {
      const designs = await storage.getAllDesigns();
      res.json(designs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch designs" });
    }
  });

  app.get("/api/designs/:id", async (req, res) => {
    try {
      const design = await storage.getDesign(Number(req.params.id));
      if (!design) {
        return res.status(404).json({ message: "Design not found" });
      }
      res.json(design);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch design" });
    }
  });

  app.post("/api/designs", async (req, res) => {
    try {
      const validatedData = insertDesignSchema.parse(req.body);
      const design = await storage.createDesign(validatedData);
      res.status(201).json(design);
    } catch (error) {
      res.status(400).json({ message: "Invalid design data" });
    }
  });

  app.put("/api/designs/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const validatedData = insertDesignSchema.parse(req.body);
      const design = await storage.updateDesign(id, validatedData);
      if (!design) {
        return res.status(404).json({ message: "Design not found" });
      }
      res.json(design);
    } catch (error) {
      res.status(400).json({ message: "Invalid design data" });
    }
  });

  // A/B Testing endpoints
  app.get("/api/ab-tests", async (req, res) => {
    try {
      const tests = await storage.getAllABTests();
      res.json(tests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch A/B tests" });
    }
  });

  app.get("/api/ab-tests/:id", async (req, res) => {
    try {
      const test = await storage.getABTest(Number(req.params.id));
      if (!test) {
        return res.status(404).json({ message: "A/B test not found" });
      }
      res.json(test);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch A/B test" });
    }
  });

  app.post("/api/ab-tests", async (req, res) => {
    try {
      const validatedData = insertABTestSchema.parse(req.body);
      const test = await storage.createABTest(validatedData);
      res.status(201).json(test);
    } catch (error) {
      res.status(400).json({ message: "Invalid A/B test data" });
    }
  });

  app.put("/api/ab-tests/:id/status", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const { status } = req.body;
      if (typeof status !== "string" || !["draft", "active", "completed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      const test = await storage.updateABTestStatus(id, status);
      if (!test) {
        return res.status(404).json({ message: "A/B test not found" });
      }
      res.json(test);
    } catch (error) {
      res.status(500).json({ message: "Failed to update A/B test status" });
    }
  });

  // Test Results endpoints
  app.get("/api/ab-tests/:id/results", async (req, res) => {
    try {
      const testId = Number(req.params.id);
      const results = await storage.getTestResults(testId);
      if (!results) {
        return res.status(404).json({ message: "Test results not found" });
      }
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch test results" });
    }
  });

  app.post("/api/ab-tests/:id/results", async (req, res) => {
    try {
      const testId = Number(req.params.id);
      const validatedData = insertTestResultsSchema.parse({ ...req.body, testId });
      const results = await storage.updateTestResults(validatedData);
      res.json(results);
    } catch (error) {
      res.status(400).json({ message: "Invalid test results data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
