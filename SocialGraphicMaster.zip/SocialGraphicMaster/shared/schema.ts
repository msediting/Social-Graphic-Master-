import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Template model
export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  category: text("category").notNull(),
  thumbnail: text("thumbnail"),
  canvasData: jsonb("canvas_data").notNull(),
});

export const insertTemplateSchema = createInsertSchema(templates).pick({
  name: true,
  description: true,
  width: true,
  height: true,
  category: true,
  thumbnail: true,
  canvasData: true,
});

// Design model
export const designs = pgTable("designs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  canvasData: jsonb("canvas_data").notNull(),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertDesignSchema = createInsertSchema(designs).pick({
  name: true,
  canvasData: true,
  width: true,
  height: true,
});

// A/B Test model
export const abTests = pgTable("ab_tests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  designAId: integer("design_a_id").notNull(),
  designBId: integer("design_b_id").notNull(),
  goal: text("goal").notNull(),
  platforms: jsonb("platforms").notNull(),
  duration: integer("duration").notNull(), // in days
  weightA: integer("weight_a").notNull(),
  weightB: integer("weight_b").notNull(),
  status: text("status").notNull().default("draft"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertABTestSchema = createInsertSchema(abTests).omit({
  id: true,
  createdAt: true,
});

// Results model
export const testResults = pgTable("test_results", {
  id: serial("id").primaryKey(),
  testId: integer("test_id").notNull(),
  impressionsA: integer("impressions_a").notNull().default(0),
  impressionsB: integer("impressions_b").notNull().default(0),
  clicksA: integer("clicks_a").notNull().default(0),
  clicksB: integer("clicks_b").notNull().default(0),
  conversionsA: integer("conversions_a").notNull().default(0),
  conversionsB: integer("conversions_b").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertTestResultsSchema = createInsertSchema(testResults).omit({
  id: true,
  updatedAt: true,
});

// Types
export type Template = typeof templates.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;

export type Design = typeof designs.$inferSelect;
export type InsertDesign = z.infer<typeof insertDesignSchema>;

export type ABTest = typeof abTests.$inferSelect;
export type InsertABTest = z.infer<typeof insertABTestSchema>;

export type TestResult = typeof testResults.$inferSelect;
export type InsertTestResult = z.infer<typeof insertTestResultsSchema>;
