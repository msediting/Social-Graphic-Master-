import { Template } from "@shared/schema";

// Social media platform info
export interface SocialMediaPlatform {
  id: string;
  name: string;
  sizes: SocialMediaSize[];
  icon: string;
}

// Social media size presets
export interface SocialMediaSize {
  id: string;
  name: string;
  width: number;
  height: number;
  description: string;
}

// Template categories for organization
export const templateCategories = [
  { id: "instagram", name: "Instagram" },
  { id: "facebook", name: "Facebook" },
  { id: "twitter", name: "Twitter" },
  { id: "linkedin", name: "LinkedIn" },
  { id: "pinterest", name: "Pinterest" },
  { id: "youtube", name: "YouTube" },
  { id: "tiktok", name: "TikTok" },
  { id: "ads", name: "Ads & Marketing" },
];

// Template types
export enum TemplateType {
  POST = "post",
  STORY = "story",
  BANNER = "banner",
  COVER = "cover",
  AD = "ad",
  THUMBNAIL = "thumbnail",
}

// Template color schemes
export interface ColorScheme {
  id: string;
  name: string;
  colors: string[];
}

export const colorSchemes: ColorScheme[] = [
  {
    id: "purple-gradient",
    name: "Purple Gradient",
    colors: ["#6366F1", "#8B5CF6", "#EC4899"],
  },
  {
    id: "blue-gradient",
    name: "Blue Gradient",
    colors: ["#3B82F6", "#2563EB", "#1D4ED8"],
  },
  {
    id: "green-gradient",
    name: "Green Gradient",
    colors: ["#10B981", "#059669", "#047857"],
  },
  {
    id: "red-gradient",
    name: "Red Gradient",
    colors: ["#EF4444", "#DC2626", "#B91C1C"],
  },
  {
    id: "orange-gradient",
    name: "Orange Gradient",
    colors: ["#F59E0B", "#D97706", "#B45309"],
  },
];

// Template backgrounds
export interface TemplateBackground {
  type: 'solid' | 'gradient' | 'image';
  value: string | string[];
  direction?: string;
}

// Helper function to create template canvas data
export function createTemplateCanvasData(
  background: TemplateBackground,
  objects: any[] = []
): any {
  if (background.type === 'gradient') {
    return {
      background: {
        type: 'gradient',
        colors: background.value as string[],
        direction: background.direction || 'to-br',
      },
      objects,
    };
  } else if (background.type === 'solid') {
    return {
      background: {
        type: 'solid',
        color: background.value as string,
      },
      objects,
    };
  } else {
    return {
      background: {
        type: 'image',
        src: background.value as string,
      },
      objects,
    };
  }
}

// Create a template object from parameters
export function createTemplate(
  name: string,
  description: string,
  width: number,
  height: number,
  category: string,
  thumbnail: string,
  background: TemplateBackground,
  objects: any[] = []
): Partial<Template> {
  return {
    name,
    description,
    width,
    height,
    category,
    thumbnail,
    canvasData: createTemplateCanvasData(background, objects),
  };
}
