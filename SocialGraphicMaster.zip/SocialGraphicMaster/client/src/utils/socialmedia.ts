import { SocialMediaPlatform, SocialMediaSize, TemplateType } from "./templates";

// Define social media platforms and their size presets
export const socialMediaPlatforms: SocialMediaPlatform[] = [
  {
    id: "instagram",
    name: "Instagram",
    icon: "instagram",
    sizes: [
      {
        id: "instagram-post",
        name: "Instagram Post",
        width: 1080,
        height: 1080,
        description: "Square post for Instagram feed"
      },
      {
        id: "instagram-story",
        name: "Instagram Story",
        width: 1080,
        height: 1920,
        description: "Vertical story for Instagram"
      },
      {
        id: "instagram-portrait",
        name: "Instagram Portrait",
        width: 1080,
        height: 1350,
        description: "Portrait orientation for Instagram"
      },
      {
        id: "instagram-landscape",
        name: "Instagram Landscape",
        width: 1080,
        height: 608,
        description: "Landscape orientation for Instagram"
      },
      {
        id: "instagram-reels",
        name: "Instagram Reels",
        width: 1080,
        height: 1920,
        description: "Vertical format for Instagram Reels"
      }
    ]
  },
  {
    id: "facebook",
    name: "Facebook",
    icon: "facebook",
    sizes: [
      {
        id: "facebook-post",
        name: "Facebook Post",
        width: 1200,
        height: 630,
        description: "Standard post for Facebook feed"
      },
      {
        id: "facebook-cover",
        name: "Facebook Cover",
        width: 851,
        height: 315,
        description: "Cover image for Facebook page"
      },
      {
        id: "facebook-profile",
        name: "Facebook Profile",
        width: 180,
        height: 180,
        description: "Profile image for Facebook"
      },
      {
        id: "facebook-event",
        name: "Facebook Event",
        width: 1920,
        height: 1080,
        description: "Event cover image for Facebook"
      }
    ]
  },
  {
    id: "twitter",
    name: "Twitter",
    icon: "twitter",
    sizes: [
      {
        id: "twitter-post",
        name: "Twitter Post",
        width: 1200,
        height: 675,
        description: "Standard post for Twitter feed"
      },
      {
        id: "twitter-header",
        name: "Twitter Header",
        width: 1500,
        height: 500,
        description: "Header image for Twitter profile"
      },
      {
        id: "twitter-profile",
        name: "Twitter Profile",
        width: 400,
        height: 400,
        description: "Profile image for Twitter"
      }
    ]
  },
  {
    id: "linkedin",
    name: "LinkedIn",
    icon: "linkedin",
    sizes: [
      {
        id: "linkedin-post",
        name: "LinkedIn Post",
        width: 1200,
        height: 627,
        description: "Standard post for LinkedIn feed"
      },
      {
        id: "linkedin-cover",
        name: "LinkedIn Cover",
        width: 1584,
        height: 396,
        description: "Cover image for LinkedIn profile"
      },
      {
        id: "linkedin-profile",
        name: "LinkedIn Profile",
        width: 400,
        height: 400,
        description: "Profile image for LinkedIn"
      }
    ]
  },
  {
    id: "pinterest",
    name: "Pinterest",
    icon: "pinterest",
    sizes: [
      {
        id: "pinterest-pin",
        name: "Pinterest Pin",
        width: 1000,
        height: 1500,
        description: "Standard pin for Pinterest"
      },
      {
        id: "pinterest-profile",
        name: "Pinterest Profile",
        width: 165,
        height: 165,
        description: "Profile image for Pinterest"
      },
      {
        id: "pinterest-board-cover",
        name: "Pinterest Board Cover",
        width: 222,
        height: 150,
        description: "Cover image for Pinterest board"
      }
    ]
  },
  {
    id: "youtube",
    name: "YouTube",
    icon: "youtube",
    sizes: [
      {
        id: "youtube-thumbnail",
        name: "YouTube Thumbnail",
        width: 1280,
        height: 720,
        description: "Thumbnail for YouTube videos"
      },
      {
        id: "youtube-banner",
        name: "YouTube Banner",
        width: 2560,
        height: 1440,
        description: "Channel banner for YouTube"
      },
      {
        id: "youtube-profile",
        name: "YouTube Profile",
        width: 800,
        height: 800,
        description: "Profile image for YouTube"
      }
    ]
  }
];

// Get a platform by ID
export function getPlatformById(id: string): SocialMediaPlatform | undefined {
  return socialMediaPlatforms.find(platform => platform.id === id);
}

// Get a size by ID
export function getSizeById(id: string): SocialMediaSize | undefined {
  for (const platform of socialMediaPlatforms) {
    const size = platform.sizes.find(size => size.id === id);
    if (size) return size;
  }
  return undefined;
}

// Get all sizes as a flat array
export function getAllSizes(): SocialMediaSize[] {
  return socialMediaPlatforms.flatMap(platform => platform.sizes);
}

// Get sizes for a specific platform
export function getSizesForPlatform(platformId: string): SocialMediaSize[] {
  const platform = getPlatformById(platformId);
  return platform ? platform.sizes : [];
}

// Get suggested dimensions for a template type
export function getDimensionsForTemplateType(type: TemplateType): { width: number; height: number } {
  switch (type) {
    case TemplateType.POST:
      return { width: 1080, height: 1080 };
    case TemplateType.STORY:
      return { width: 1080, height: 1920 };
    case TemplateType.BANNER:
      return { width: 1584, height: 396 };
    case TemplateType.COVER:
      return { width: 851, height: 315 };
    case TemplateType.AD:
      return { width: 1200, height: 628 };
    case TemplateType.THUMBNAIL:
      return { width: 1280, height: 720 };
    default:
      return { width: 1080, height: 1080 };
  }
}
