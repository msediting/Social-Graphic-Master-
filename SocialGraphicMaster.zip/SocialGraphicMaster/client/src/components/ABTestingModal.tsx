import { FC, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress"; 
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CheckCheck, ArrowLeft } from "lucide-react";
import { ABTest, InsertABTest } from "@shared/schema";

interface ABTestingModalProps {
  isOpen: boolean;
  onClose: () => void;
  designId?: number;
  comparisonDesignId?: number;
}

const ABTestingModal: FC<ABTestingModalProps> = ({ 
  isOpen, 
  onClose, 
  designId, 
  comparisonDesignId 
}) => {
  const { toast } = useToast();
  const [testName, setTestName] = useState("Untitled A/B Test");
  const [testDuration, setTestDuration] = useState("7");
  const [platforms, setPlatforms] = useState<string[]>(['instagram', 'facebook']);
  const [goal, setGoal] = useState("ctr");
  const [weightDistribution, setWeightDistribution] = useState(50);
  
  const { data: designA } = useQuery({
    queryKey: designId ? [`/api/designs/${designId}`] : null,
    enabled: !!designId
  });
  
  const { data: designB } = useQuery({
    queryKey: comparisonDesignId ? [`/api/designs/${comparisonDesignId}`] : null,
    enabled: !!comparisonDesignId
  });
  
  const createABTest = useMutation({
    mutationFn: async (testData: InsertABTest) => {
      const res = await apiRequest('POST', '/api/ab-tests', testData);
      return res.json();
    },
    onSuccess: (data: ABTest) => {
      queryClient.invalidateQueries({ queryKey: ['/api/ab-tests'] });
      toast({
        title: "A/B Test created",
        description: "Your test has been set up successfully.",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error creating test",
        description: "There was an error setting up your A/B test. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const handleStartTest = () => {
    if (!designId || !comparisonDesignId) {
      toast({
        title: "Missing designs",
        description: "Both designs must be saved before starting an A/B test.",
        variant: "destructive",
      });
      return;
    }
    
    const testData: InsertABTest = {
      name: testName,
      designAId: designId,
      designBId: comparisonDesignId,
      goal,
      platforms,
      duration: parseInt(testDuration),
      weightA: weightDistribution,
      weightB: 100 - weightDistribution,
      status: "draft"
    };
    
    createABTest.mutate(testData);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-full w-[95%] md:w-[90%] max-h-[95vh]">
        <DialogHeader>
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="icon" onClick={onClose}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <DialogTitle className="text-lg font-semibold">A/B Testing</DialogTitle>
          </div>
        </DialogHeader>
        
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          <div className="md:w-3/4 flex flex-col md:flex-row overflow-auto">
            {/* Version A */}
            <div className="flex-1 p-4 border-b md:border-b-0 md:border-r border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-800">Version A</h3>
                <div className="flex items-center">
                  <span className="text-xs font-semibold px-2 py-1 bg-indigo-100 text-indigo-800 rounded-md mr-2">Current</span>
                  <Button variant="ghost" size="icon">
                    <span className="sr-only">Edit</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
                      <path d="m15 5 4 4"/>
                    </svg>
                  </Button>
                </div>
              </div>
              
              <div className="aspect-square max-w-xs mx-auto bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-lg shadow-lg relative">
                {designA && (
                  <div className="absolute inset-0 flex items-center justify-center text-white">
                    <p>{designA.name}</p>
                  </div>
                )}
              </div>
            </div>
            
            {/* Version B */}
            <div className="flex-1 p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-800">Version B</h3>
                <div className="flex items-center">
                  <span className="text-xs font-semibold px-2 py-1 bg-purple-100 text-purple-800 rounded-md mr-2">Variant</span>
                  <Button variant="ghost" size="icon">
                    <span className="sr-only">Edit</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
                      <path d="m15 5 4 4"/>
                    </svg>
                  </Button>
                </div>
              </div>
              
              <div className="aspect-square max-w-xs mx-auto bg-gradient-to-tr from-blue-500 via-indigo-500 to-purple-500 rounded-lg shadow-lg relative">
                {designB && (
                  <div className="absolute inset-0 flex items-center justify-center text-white">
                    <p>{designB.name}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Analytics Panel */}
          <div className="md:w-1/4 border-l border-gray-200 p-4 overflow-y-auto">
            <h3 className="font-semibold text-gray-800 mb-4">Test Analytics</h3>
            
            <div className="space-y-4">
              <div>
                <Label>Test Name</Label>
                <Input
                  value={testName}
                  onChange={(e) => setTestName(e.target.value)}
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label>Test Duration</Label>
                <Select value={testDuration} onValueChange={setTestDuration}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select duration" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">24 hours</SelectItem>
                    <SelectItem value="3">3 days</SelectItem>
                    <SelectItem value="7">7 days</SelectItem>
                    <SelectItem value="14">14 days</SelectItem>
                    <SelectItem value="30">30 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Target Platforms</Label>
                <div className="space-y-2 mt-1">
                  <div className="flex items-center">
                    <Checkbox
                      id="instagram"
                      checked={platforms.includes('instagram')}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setPlatforms([...platforms, 'instagram']);
                        } else {
                          setPlatforms(platforms.filter(p => p !== 'instagram'));
                        }
                      }}
                    />
                    <label htmlFor="instagram" className="ml-2 text-sm text-gray-700">
                      Instagram
                    </label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox
                      id="facebook"
                      checked={platforms.includes('facebook')}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setPlatforms([...platforms, 'facebook']);
                        } else {
                          setPlatforms(platforms.filter(p => p !== 'facebook'));
                        }
                      }}
                    />
                    <label htmlFor="facebook" className="ml-2 text-sm text-gray-700">
                      Facebook
                    </label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox
                      id="twitter"
                      checked={platforms.includes('twitter')}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setPlatforms([...platforms, 'twitter']);
                        } else {
                          setPlatforms(platforms.filter(p => p !== 'twitter'));
                        }
                      }}
                    />
                    <label htmlFor="twitter" className="ml-2 text-sm text-gray-700">
                      Twitter
                    </label>
                  </div>
                </div>
              </div>
              
              <div>
                <Label>Testing Goals</Label>
                <Select value={goal} onValueChange={setGoal}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select goal" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="engagement">Engagement Rate</SelectItem>
                    <SelectItem value="ctr">Click-through Rate</SelectItem>
                    <SelectItem value="impressions">Impressions</SelectItem>
                    <SelectItem value="conversion">Conversion Rate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Weight Distribution</Label>
                <div className="flex items-center space-x-2 mb-2 mt-1">
                  <Progress value={weightDistribution} className="h-2" />
                  <span className="text-xs text-gray-600">{weightDistribution}%</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress value={100 - weightDistribution} className="h-2" />
                  <span className="text-xs text-gray-600">{100 - weightDistribution}%</span>
                </div>
                <Slider
                  value={[weightDistribution]}
                  min={0}
                  max={100}
                  step={5}
                  onValueChange={(value) => setWeightDistribution(value[0])}
                  className="mt-2"
                />
              </div>
              
              <div className="pt-3 border-t border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-medium text-gray-600">Projected Audience</h4>
                  <span className="text-xs text-gray-500">Based on your account</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="h-4 w-4 bg-indigo-500 rounded-sm"></div>
                  <span className="text-xs text-gray-700">~1,240 impressions per version</span>
                </div>
              </div>
              
              <Button className="w-full" onClick={handleStartTest}>
                <CheckCheck className="mr-2 h-4 w-4" />
                Start A/B Test
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ABTestingModal;
