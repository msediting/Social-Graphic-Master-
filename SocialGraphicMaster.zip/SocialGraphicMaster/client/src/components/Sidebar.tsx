import { FC } from "react";
import { Link, useLocation } from "wouter";
import { 
  Search, 
  Shapes, 
  Image as ImageIcon, 
  Type, 
  Loader, 
  PieChart, 
  Palette, 
  FlaskRound, 
  HelpCircle 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

type NavItem = {
  icon: React.ReactNode;
  label: string;
  href: string;
};

const Sidebar: FC = () => {
  const [location] = useLocation();

  const navItems: NavItem[] = [
    { 
      icon: <Shapes className="w-5 h-5" />, 
      label: "Templates", 
      href: "/" 
    },
    { 
      icon: <ImageIcon className="w-5 h-5" />, 
      label: "Photos", 
      href: "/photos" 
    },
    { 
      icon: <Type className="w-5 h-5" />, 
      label: "Text", 
      href: "/text" 
    },
    { 
      icon: <Loader className="w-5 h-5" />, 
      label: "Elements", 
      href: "/elements" 
    },
    { 
      icon: <PieChart className="w-5 h-5" />, 
      label: "Charts", 
      href: "/charts" 
    },
    { 
      icon: <Palette className="w-5 h-5" />, 
      label: "Styles", 
      href: "/styles" 
    },
    { 
      icon: <FlaskRound className="w-5 h-5" />, 
      label: "A/B Testing", 
      href: "/ab-testing" 
    },
  ];

  return (
    <div className="w-16 md:w-64 bg-white border-r border-gray-200 flex flex-col h-full">
      <div className="hidden md:block p-4">
        <div className="relative">
          <Input 
            type="text" 
            placeholder="Search templates..." 
            className="w-full pl-8"
          />
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
        </div>
      </div>
      
      <nav className="flex-1 overflow-y-auto py-4">
        <ul>
          {navItems.map((item, index) => (
            <li key={index} className="mb-1">
              <Link href={item.href}>
                <a 
                  className={cn(
                    "flex items-center px-4 py-2.5 text-gray-600 hover:bg-gray-100",
                    location === item.href && "text-primary bg-indigo-50 border-r-4 border-primary"
                  )}
                >
                  <div className="w-5 text-center md:mr-3">{item.icon}</div>
                  <span className="hidden md:block font-medium">{item.label}</span>
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <Link href="/help">
          <a className="hidden md:flex items-center text-sm text-gray-600 hover:text-primary">
            <HelpCircle className="h-4 w-4 mr-2" />
            <span>Help & Support</span>
          </a>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
