import { FC, useRef, useEffect, useState } from "react";
import * as fabric from "fabric";
import { Button } from "@/components/ui/button";
import { Undo, Redo, ZoomIn, ZoomOut } from "lucide-react";
import { initializeFabricCanvas, addTextToCanvas, addImageToCanvas, addShapeToCanvas } from "@/lib/fabricHelpers";

interface CanvasProps {
  width: number;
  height: number;
  canvasData?: any;
  onCanvasChange?: (canvas: fabric.Canvas) => void;
  onObjectSelected?: (object: fabric.Object | null) => void;
}

const Canvas: FC<CanvasProps> = ({ 
  width, 
  height, 
  canvasData, 
  onCanvasChange,
  onObjectSelected
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricRef = useRef<fabric.Canvas | null>(null);
  const [zoom, setZoom] = useState(100);
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (canvasRef.current && !fabricRef.current) {
      const canvas = initializeFabricCanvas(canvasRef.current, {
        width,
        height,
        backgroundColor: "#ffffff"
      });
      
      fabricRef.current = canvas;
      
      // Setup event listeners
      canvas.on('object:modified', () => {
        onCanvasChange?.(canvas);
      });
      
      canvas.on('object:added', () => {
        onCanvasChange?.(canvas);
      });
      
      canvas.on('object:removed', () => {
        onCanvasChange?.(canvas);
      });
      
      canvas.on('selection:created', (e) => {
        onObjectSelected?.(e.target || null);
      });
      
      canvas.on('selection:updated', (e) => {
        onObjectSelected?.(e.target || null);
      });
      
      canvas.on('selection:cleared', () => {
        onObjectSelected?.(null);
      });
      
      // Load canvas data if available
      if (canvasData) {
        // Apply background
        if (canvasData.background) {
          if (canvasData.background.type === "gradient") {
            // Create gradient background logic
            const gradientBg = new fabric.Rect({
              left: 0,
              top: 0,
              width: canvas.width,
              height: canvas.height,
              fill: `linear-gradient(${canvasData.background.direction || 'to bottom'}, ${
                canvasData.background.colors.join(', ')
              })`,
              selectable: false,
              evented: false,
            });
            canvas.add(gradientBg);
            canvas.sendToBack(gradientBg);
          } else if (canvasData.background.type === "solid") {
            canvas.setBackgroundColor(canvasData.background.color, canvas.renderAll.bind(canvas));
          }
        }

        // Load objects if any
        if (canvasData.objects && Array.isArray(canvasData.objects)) {
          canvasData.objects.forEach((obj: any) => {
            if (obj.type === 'text') {
              addTextToCanvas(canvas, obj.text, obj.options);
            } else if (obj.type === 'image') {
              addImageToCanvas(canvas, obj.src, obj.options);
            } else if (obj.type === 'shape') {
              addShapeToCanvas(canvas, obj.shape, obj.options);
            }
          });
        }
      }
      
      onCanvasChange?.(canvas);
    }
    
    return () => {
      if (fabricRef.current) {
        fabricRef.current.dispose();
        fabricRef.current = null;
      }
    };
  }, []);
  
  const handleZoomIn = () => {
    if (fabricRef.current && zoom < 200) {
      const newZoom = zoom + 10;
      fabricRef.current.setZoom(newZoom / 100);
      setZoom(newZoom);
    }
  };
  
  const handleZoomOut = () => {
    if (fabricRef.current && zoom > 50) {
      const newZoom = zoom - 10;
      fabricRef.current.setZoom(newZoom / 100);
      setZoom(newZoom);
    }
  };
  
  const handleUndo = () => {
    if (fabricRef.current) {
      // Undo implementation would go here
      // This would require maintaining history
      console.log("Undo");
    }
  };
  
  const handleRedo = () => {
    if (fabricRef.current) {
      // Redo implementation would go here
      console.log("Redo");
    }
  };
  
  return (
    <div className="flex-1 bg-gray-100 overflow-auto flex items-center justify-center p-4">
      <div ref={containerRef} className="relative">
        {/* Canvas container with rulers */}
        <div className="absolute -left-6 top-0 h-full w-6 bg-white border-r border-gray-300 flex flex-col">
          <div className="h-6"></div>
          <div className="flex-1 relative">
            <div className="absolute top-0 left-0 w-full h-full flex flex-col">
              {Array.from({ length: 5 }).map((_, i) => (
                <div 
                  key={i} 
                  className="border-b border-gray-300 flex items-center justify-center text-[10px] text-gray-500"
                  style={{ height: `${height / 5}px` }}
                >
                  {(i + 1) * 100}
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="absolute -top-6 left-0 w-full h-6 bg-white border-b border-gray-300 flex flex-row">
          {Array.from({ length: 5 }).map((_, i) => (
            <div 
              key={i} 
              className="border-r border-gray-300 flex items-center justify-center text-[10px] text-gray-500"
              style={{ width: `${width / 5}px` }}
            >
              {(i + 1) * 100}
            </div>
          ))}
        </div>
        
        {/* Canvas element */}
        <canvas ref={canvasRef} />
        
        {/* Canvas toolbar */}
        <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 bg-white rounded-full shadow-md px-1 py-1 flex items-center space-x-1">
          <Button variant="ghost" size="icon" className="rounded-full" onClick={handleZoomOut}>
            <ZoomOut className="h-4 w-4" />
          </Button>
          <div className="px-3 py-1 text-sm">{zoom}%</div>
          <Button variant="ghost" size="icon" className="rounded-full" onClick={handleZoomIn}>
            <ZoomIn className="h-4 w-4" />
          </Button>
          <div className="w-px h-5 bg-gray-300 mx-1"></div>
          <Button variant="ghost" size="icon" className="rounded-full" onClick={handleUndo}>
            <Undo className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full" onClick={handleRedo}>
            <Redo className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Canvas;
