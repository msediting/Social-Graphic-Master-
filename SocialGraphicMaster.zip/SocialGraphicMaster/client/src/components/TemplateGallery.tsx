import { FC, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Template } from "@shared/schema";
import { Link } from "wouter";
import { Filter, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Edit } from "lucide-react";

interface TemplateCardProps {
  template: Template;
}

const TemplateCard: FC<TemplateCardProps> = ({ template }) => {
  return (
    <Link href={`/editor/${template.id}`}>
      <a className="group relative bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition cursor-pointer">
        <img 
          src={template.thumbnail} 
          alt={template.name} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-3">
          <span className="text-white text-sm font-medium">{template.name}</span>
          <Button size="icon" variant="secondary" className="h-7 w-7 rounded-full">
            <Edit className="h-3.5 w-3.5" />
          </Button>
        </div>
        <div className="p-3">
          <h3 className="text-sm font-medium text-gray-800 truncate">{template.description}</h3>
          <p className="text-xs text-gray-500 mt-1">{template.width} × {template.height}px</p>
        </div>
      </a>
    </Link>
  );
};

const TemplateSkeleton: FC = () => (
  <div className="bg-white rounded-lg overflow-hidden shadow-sm">
    <Skeleton className="w-full h-48" />
    <div className="p-3">
      <Skeleton className="h-5 w-3/4 mb-2" />
      <Skeleton className="h-4 w-1/2" />
    </div>
  </div>
);

const TemplateGallery: FC = () => {
  const { data: templates, isLoading } = useQuery({
    queryKey: ["/api/templates"],
  });

  const [filter, setFilter] = useState("all");

  const filteredTemplates = templates 
    ? filter === "all" 
      ? templates 
      : templates.filter((template: Template) => template.category === filter)
    : [];

  return (
    <div className="flex-1 flex flex-col bg-gray-50 overflow-hidden">
      <div className="p-4 border-b border-gray-200 bg-white flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-800">Social Media Templates</h2>
        <div className="flex items-center space-x-3">
          <div className="hidden md:flex items-center space-x-2">
            <Button variant="outline" size="sm" className="flex items-center">
              <span>Size</span>
              <ChevronDown className="ml-1 h-3.5 w-3.5" />
            </Button>
            <Button variant="outline" size="sm" className="flex items-center">
              <span>Sort by</span>
              <ChevronDown className="ml-1 h-3.5 w-3.5" />
            </Button>
          </div>
          <Button variant="outline" size="sm" className="flex items-center">
            <Filter className="h-4 w-4 md:mr-1.5" />
            <span className="hidden md:inline">Filters</span>
          </Button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4">
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[...Array(10)].map((_, i) => (
              <TemplateSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredTemplates.map((template: Template) => (
              <TemplateCard key={template.id} template={template} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TemplateGallery;
