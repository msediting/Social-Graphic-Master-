import { FC, useEffect, useState, RefObject } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import * as fabric from "fabric";
import { ArrowDown, ArrowRight, UnfoldVertical, Crop, Wand2, Sliders, PanelBottomDashed } from "lucide-react";

interface PropertyPanelProps {
  selectedObject: fabric.Object | null;
  canvasRef: RefObject<fabric.Canvas | null>;
}

const PropertyPanel: FC<PropertyPanelProps> = ({ selectedObject, canvasRef }) => {
  const [objectType, setObjectType] = useState<string | null>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [size, setSize] = useState({ width: 0, height: 0 });
  const [opacity, setOpacity] = useState(100);
  const [maintainAspectRatio, setMaintainAspectRatio] = useState(true);
  const [backgroundType, setBackgroundType] = useState<'gradient' | 'solid' | 'image'>('gradient');
  
  useEffect(() => {
    if (selectedObject) {
      // Determine object type
      if (selectedObject instanceof fabric.Image) {
        setObjectType('image');
      } else if (selectedObject instanceof fabric.Text) {
        setObjectType('text');
      } else if (selectedObject instanceof fabric.Rect || 
                selectedObject instanceof fabric.Circle ||
                selectedObject instanceof fabric.Polygon) {
        setObjectType('shape');
      } else {
        setObjectType('object');
      }
      
      // Set position
      setPosition({
        x: Math.round(selectedObject.left || 0),
        y: Math.round(selectedObject.top || 0)
      });
      
      // Set size
      setSize({
        width: Math.round(selectedObject.width || 0),
        height: Math.round(selectedObject.height || 0)
      });
      
      // Set opacity
      setOpacity(Math.round((selectedObject.opacity || 1) * 100));
    } else {
      setObjectType(null);
    }
  }, [selectedObject]);
  
  const updatePosition = (axis: 'x' | 'y', value: number) => {
    if (selectedObject && canvasRef.current) {
      if (axis === 'x') {
        selectedObject.set('left', value);
        setPosition(prev => ({ ...prev, x: value }));
      } else {
        selectedObject.set('top', value);
        setPosition(prev => ({ ...prev, y: value }));
      }
      canvasRef.current.renderAll();
    }
  };
  
  const updateSize = (dimension: 'width' | 'height', value: number) => {
    if (selectedObject && canvasRef.current) {
      const newSize = { ...size };
      
      if (dimension === 'width') {
        newSize.width = value;
        if (maintainAspectRatio && size.height > 0 && size.width > 0) {
          const ratio = size.height / size.width;
          newSize.height = Math.round(value * ratio);
        }
      } else {
        newSize.height = value;
        if (maintainAspectRatio && size.height > 0 && size.width > 0) {
          const ratio = size.width / size.height;
          newSize.width = Math.round(value * ratio);
        }
      }
      
      selectedObject.set({
        scaleX: newSize.width / (selectedObject.width || 1),
        scaleY: newSize.height / (selectedObject.height || 1)
      });
      
      setSize(newSize);
      canvasRef.current.renderAll();
    }
  };
  
  const updateOpacity = (value: number) => {
    if (selectedObject && canvasRef.current) {
      selectedObject.set('opacity', value / 100);
      setOpacity(value);
      canvasRef.current.renderAll();
    }
  };
  
  const renderImageProperties = () => (
    <div className="p-4 border-b border-gray-200">
      <h3 className="text-sm font-semibold text-gray-700">Image Properties</h3>
      
      <div className="mt-4 space-y-4">
        <div>
          <Label className="text-xs font-medium text-gray-600">Position</Label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            <div>
              <Label className="text-xs text-gray-500">X</Label>
              <Input
                type="number"
                value={position.x}
                onChange={(e) => updatePosition('x', parseInt(e.target.value))}
                className="mt-1 text-sm"
              />
            </div>
            <div>
              <Label className="text-xs text-gray-500">Y</Label>
              <Input
                type="number"
                value={position.y}
                onChange={(e) => updatePosition('y', parseInt(e.target.value))}
                className="mt-1 text-sm"
              />
            </div>
          </div>
        </div>
        
        <div>
          <Label className="text-xs font-medium text-gray-600">Size</Label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            <div>
              <Label className="text-xs text-gray-500">W</Label>
              <Input
                type="number"
                value={size.width}
                onChange={(e) => updateSize('width', parseInt(e.target.value))}
                className="mt-1 text-sm"
              />
            </div>
            <div>
              <Label className="text-xs text-gray-500">H</Label>
              <Input
                type="number"
                value={size.height}
                onChange={(e) => updateSize('height', parseInt(e.target.value))}
                className="mt-1 text-sm"
              />
            </div>
          </div>
          <div className="flex items-center mt-1">
            <Checkbox
              id="lock-ratio"
              checked={maintainAspectRatio}
              onCheckedChange={(checked) => setMaintainAspectRatio(!!checked)}
            />
            <label htmlFor="lock-ratio" className="ml-2 text-xs text-gray-500">
              Maintain aspect ratio
            </label>
          </div>
        </div>
        
        <div>
          <Label className="text-xs font-medium text-gray-600">Opacity</Label>
          <div className="flex items-center space-x-2 mt-1">
            <Slider
              value={[opacity]}
              min={0}
              max={100}
              step={1}
              onValueChange={(value) => updateOpacity(value[0])}
              className="flex-1"
            />
            <span className="text-xs text-gray-500">{opacity}%</span>
          </div>
        </div>
        
        <div>
          <Label className="text-xs font-medium text-gray-600">Effects</Label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            <Button variant="outline" size="sm" className="text-xs">
              <Crop className="h-3.5 w-3.5 mr-1" />
              <span>Crop</span>
            </Button>
            <Button variant="outline" size="sm" className="text-xs">
              <Wand2 className="h-3.5 w-3.5 mr-1" />
              <span>Filters</span>
            </Button>
            <Button variant="outline" size="sm" className="text-xs">
              <Sliders className="h-3.5 w-3.5 mr-1" />
              <span>Adjust</span>
            </Button>
            <Button variant="outline" size="sm" className="text-xs">
              <PanelBottomDashed className="h-3.5 w-3.5 mr-1" />
              <span>Border</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
  
  const renderBackgroundProperties = () => (
    <div className="p-4">
      <h3 className="text-sm font-semibold text-gray-700">Background</h3>
      
      <div className="mt-4 space-y-4">
        <div>
          <Label className="text-xs font-medium text-gray-600">Type</Label>
          <div className="grid grid-cols-3 gap-2 mt-1">
            <Button 
              variant={backgroundType === 'gradient' ? "default" : "outline"} 
              size="sm"
              onClick={() => setBackgroundType('gradient')}
              className="text-xs"
            >
              Gradient
            </Button>
            <Button 
              variant={backgroundType === 'solid' ? "default" : "outline"} 
              size="sm"
              onClick={() => setBackgroundType('solid')}
              className="text-xs"
            >
              Solid
            </Button>
            <Button 
              variant={backgroundType === 'image' ? "default" : "outline"} 
              size="sm"
              onClick={() => setBackgroundType('image')}
              className="text-xs"
            >
              Image
            </Button>
          </div>
        </div>
        
        <div>
          <Label className="text-xs font-medium text-gray-600">Colors</Label>
          <div className="flex items-center space-x-2 mt-1">
            <button className="w-6 h-6 rounded-full bg-indigo-500 ring-2 ring-indigo-500 ring-offset-2"></button>
            <button className="w-6 h-6 rounded-full bg-purple-500 ring-2 ring-purple-500 ring-offset-2"></button>
            <button className="w-6 h-6 rounded-full bg-pink-500 ring-2 ring-pink-500 ring-offset-2"></button>
            <button className="w-6 h-6 rounded-full bg-gray-200 hover:bg-gray-300 flex items-center justify-center">
              <span className="text-xs text-gray-500">+</span>
            </button>
          </div>
        </div>
        
        <div>
          <Label className="text-xs font-medium text-gray-600">Direction</Label>
          <div className="grid grid-cols-4 gap-2 mt-1">
            <Button variant="default" size="sm" className="p-1.5">
              <ArrowDown className="h-3.5 w-3.5 rotate-45" />
            </Button>
            <Button variant="outline" size="sm" className="p-1.5">
              <ArrowRight className="h-3.5 w-3.5" />
            </Button>
            <Button variant="outline" size="sm" className="p-1.5">
              <ArrowDown className="h-3.5 w-3.5" />
            </Button>
            <Button variant="outline" size="sm" className="p-1.5">
              <UnfoldVertical className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
  
  // If no object is selected, show background properties
  if (!selectedObject) {
    return (
      <div className="w-0 md:w-72 bg-white border-l border-gray-200 flex flex-col overflow-y-auto hidden md:block">
        {renderBackgroundProperties()}
      </div>
    );
  }
  
  return (
    <div className="w-0 md:w-72 bg-white border-l border-gray-200 flex flex-col overflow-y-auto hidden md:block">
      {objectType === 'image' && renderImageProperties()}
      {/* Add other property panels for text, shape, etc. */}
    </div>
  );
};

export default PropertyPanel;
