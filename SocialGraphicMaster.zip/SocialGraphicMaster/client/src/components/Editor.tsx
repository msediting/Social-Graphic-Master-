import { FC, useState, useRef } from "react";
import Canvas from "./Canvas";
import Sidebar from "./Sidebar";
import PropertyPanel from "./PropertyPanel";
import Header from "./Header";
import { useToast } from "@/hooks/use-toast";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Save, FlaskRound } from "lucide-react";
import * as fabric from "fabric";
import { Design, InsertDesign } from "@shared/schema";

const Editor: FC = () => {
  const { id } = useParams();
  const templateId = id ? parseInt(id) : undefined;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedObject, setSelectedObject] = useState<fabric.Object | null>(null);
  const canvasRef = useRef<fabric.Canvas | null>(null);
  const [designName, setDesignName] = useState("Untitled Design");
  const [showABTestingDialog, setShowABTestingDialog] = useState(false);
  
  // Fetch template data if templateId is provided
  const { data: template, isLoading: isLoadingTemplate } = useQuery({
    queryKey: [templateId ? `/api/templates/${templateId}` : null],
    enabled: !!templateId,
  });
  
  // Save design mutation
  const saveDesign = useMutation({
    mutationFn: async (design: InsertDesign) => {
      const res = await apiRequest('POST', '/api/designs', design);
      return res.json();
    },
    onSuccess: (data: Design) => {
      queryClient.invalidateQueries({ queryKey: ['/api/designs'] });
      toast({
        title: "Design saved",
        description: "Your design has been saved successfully.",
      });
      // Redirect to the editor with the new design ID
      setLocation(`/editor/${data.id}`);
    },
    onError: () => {
      toast({
        title: "Error saving design",
        description: "There was an error saving your design. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const handleCanvasChange = (canvas: fabric.Canvas) => {
    canvasRef.current = canvas;
  };
  
  const handleObjectSelected = (object: fabric.Object | null) => {
    setSelectedObject(object);
  };
  
  const handleSaveDesign = () => {
    if (!canvasRef.current) return;
    
    const canvasData = {
      objects: canvasRef.current.getObjects().map(obj => {
        // Convert fabric objects to serializable format
        return obj.toJSON();
      }),
      background: {
        type: "solid",
        color: canvasRef.current.backgroundColor
      }
    };
    
    const designData: InsertDesign = {
      name: designName,
      canvasData,
      width: canvasRef.current.width || 1080,
      height: canvasRef.current.height || 1080
    };
    
    saveDesign.mutate(designData);
  };
  
  const handleExport = () => {
    if (!canvasRef.current) return;
    
    // Get canvas data URL as image
    const dataURL = canvasRef.current.toDataURL({
      format: 'png',
      quality: 1
    });
    
    // Create a link element to download the image
    const link = document.createElement('a');
    link.download = `${designName.replace(/\s+/g, '-').toLowerCase()}.png`;
    link.href = dataURL;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Design exported",
      description: "Your design has been exported as PNG.",
    });
  };
  
  const handleStartABTest = () => {
    setShowABTestingDialog(true);
  };
  
  if (isLoadingTemplate) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }
  
  const canvasData = template?.canvasData;
  const canvasWidth = template?.width || 1080;
  const canvasHeight = template?.height || 1080;
  
  return (
    <div className="h-screen flex flex-col">
      <Header onExport={handleExport} />
      
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar Toolbox */}
        <div className="w-16 md:w-64 bg-white border-r border-gray-200 flex flex-col overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center space-x-3 mb-4">
              <Button
                variant="ghost" 
                size="icon"
                onClick={() => setLocation('/')}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h2 className="text-lg font-semibold text-gray-800 hidden md:block">Editor</h2>
            </div>
            
            <h3 className="text-sm font-semibold text-gray-700 hidden md:block">Elements</h3>
            <div className="flex flex-col md:flex-row md:flex-wrap gap-2 mt-3">
              <Button variant="outline" className="flex flex-col md:flex-row items-center justify-center w-full">
                <ImageIcon className="h-5 w-5 md:mr-2" />
                <span className="mt-1 md:mt-0 text-xs md:text-sm hidden md:block">Images</span>
              </Button>
              <Button variant="outline" className="flex flex-col md:flex-row items-center justify-center w-full">
                <Type className="h-5 w-5 md:mr-2" />
                <span className="mt-1 md:mt-0 text-xs md:text-sm hidden md:block">Text</span>
              </Button>
              <Button variant="outline" className="flex flex-col md:flex-row items-center justify-center w-full">
                <Square className="h-5 w-5 md:mr-2" />
                <span className="mt-1 md:mt-0 text-xs md:text-sm hidden md:block">Shapes</span>
              </Button>
              <Button variant="outline" className="flex flex-col md:flex-row items-center justify-center w-full">
                <Wand2 className="h-5 w-5 md:mr-2" />
                <span className="mt-1 md:mt-0 text-xs md:text-sm hidden md:block">Effects</span>
              </Button>
            </div>
          </div>
          
          <div className="p-4">
            <h3 className="text-sm font-semibold text-gray-700 hidden md:block">Social Sizes</h3>
            <div className="grid grid-cols-1 gap-2 mt-3">
              <Button variant="secondary" className="flex items-center justify-center md:justify-start">
                <Instagram className="md:mr-2 h-5 w-5" />
                <span className="hidden md:block">Instagram Post</span>
              </Button>
              <Button variant="outline" className="flex items-center justify-center md:justify-start">
                <Instagram className="md:mr-2 h-5 w-5" />
                <span className="hidden md:block">Instagram Story</span>
              </Button>
              <Button variant="outline" className="flex items-center justify-center md:justify-start">
                <Twitter className="md:mr-2 h-5 w-5" />
                <span className="hidden md:block">Twitter Post</span>
              </Button>
              <Button variant="outline" className="flex items-center justify-center md:justify-start">
                <Facebook className="md:mr-2 h-5 w-5" />
                <span className="hidden md:block">Facebook Post</span>
              </Button>
              <Button variant="outline" className="flex items-center justify-center md:justify-start">
                <Linkedin className="md:mr-2 h-5 w-5" />
                <span className="hidden md:block">LinkedIn Post</span>
              </Button>
            </div>
          </div>
          
          <div className="mt-auto p-4 border-t border-gray-200">
            <div className="grid grid-cols-1 gap-2">
              <Button onClick={handleSaveDesign} className="w-full">
                <Save className="mr-2 h-4 w-4" />
                <span>Save Design</span>
              </Button>
              <Button onClick={handleStartABTest} variant="outline" className="w-full">
                <FlaskRound className="mr-2 h-4 w-4" />
                <span>A/B Test</span>
              </Button>
            </div>
          </div>
        </div>
        
        {/* Canvas Area */}
        <Canvas 
          width={canvasWidth}
          height={canvasHeight}
          canvasData={canvasData}
          onCanvasChange={handleCanvasChange}
          onObjectSelected={handleObjectSelected}
        />
        
        {/* Right Properties Panel */}
        <PropertyPanel 
          selectedObject={selectedObject}
          canvasRef={canvasRef}
        />
      </div>
      
      {/* A/B Testing Dialog */}
      <Dialog open={showABTestingDialog} onOpenChange={setShowABTestingDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create A/B Test</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm text-gray-500">
              Save your current design first to create an A/B test. You'll be able to create a variant and compare performance.
            </p>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowABTestingDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveDesign}>
                Save Design
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

import { ImageIcon, Type, Square, Wand2, Instagram, Twitter, Facebook, Linkedin } from "lucide-react";

export default Editor;
