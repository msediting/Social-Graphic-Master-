import * as fabric from "fabric";

// Initialize a fabric canvas with default settings
export function initializeFabricCanvas(
  canvas: HTMLCanvasElement,
  options: {
    width: number;
    height: number;
    backgroundColor?: string;
  }
): fabric.Canvas {
  const fabricCanvas = new fabric.Canvas(canvas, {
    width: options.width,
    height: options.height,
    backgroundColor: options.backgroundColor || 'white',
    preserveObjectStacking: true,
    selection: true,
    defaultCursor: 'default',
    hoverCursor: 'pointer',
  });

  // Enable object scaling, rotation, and movement
  fabricCanvas.on('object:added', (e) => {
    const obj = e.target;
    if (obj) {
      obj.set({
        borderColor: '#2563eb',
        cornerColor: '#2563eb',
        cornerSize: 8,
        cornerStyle: 'circle',
        transparentCorners: false,
        lockUniScaling: false,
      });
    }
  });

  return fabricCanvas;
}

// Add text to canvas
export function addTextToCanvas(
  canvas: fabric.Canvas,
  text: string,
  options?: fabric.ITextOptions
): fabric.IText {
  const textObj = new fabric.IText(text, {
    left: 100,
    top: 100,
    fontFamily: 'Inter, sans-serif',
    fontSize: 24,
    fill: '#000000',
    ...options,
  });

  canvas.add(textObj);
  canvas.setActiveObject(textObj);
  canvas.renderAll();

  return textObj;
}

// Add image to canvas
export function addImageToCanvas(
  canvas: fabric.Canvas,
  imageUrl: string,
  options?: fabric.IImageOptions
): Promise<fabric.Image> {
  return new Promise((resolve, reject) => {
    fabric.Image.fromURL(
      imageUrl,
      (img) => {
        // Scale image if needed
        const maxWidth = canvas.getWidth() * 0.8;
        const maxHeight = canvas.getHeight() * 0.8;
        
        if (img.width && img.width > maxWidth) {
          const scale = maxWidth / img.width;
          img.scale(scale);
        }
        
        if (img.height && img.getScaledHeight() > maxHeight) {
          const scale = maxHeight / img.getScaledHeight();
          img.scale(scale);
        }
        
        // Position in center if not specified
        if (!options?.left) {
          img.set('left', (canvas.getWidth() - img.getScaledWidth()) / 2);
        }
        
        if (!options?.top) {
          img.set('top', (canvas.getHeight() - img.getScaledHeight()) / 2);
        }
        
        // Apply additional options
        img.set(options || {});
        
        canvas.add(img);
        canvas.setActiveObject(img);
        canvas.renderAll();
        resolve(img);
      },
      (err) => {
        reject(err);
      }
    );
  });
}

// Add shape to canvas
export function addShapeToCanvas(
  canvas: fabric.Canvas,
  shape: 'rect' | 'circle' | 'triangle',
  options?: fabric.IObjectOptions
): fabric.Object {
  let shapeObj: fabric.Object;
  
  switch (shape) {
    case 'rect':
      shapeObj = new fabric.Rect({
        left: 100,
        top: 100,
        width: 100,
        height: 100,
        fill: '#4f46e5',
        ...options,
      });
      break;
    case 'circle':
      shapeObj = new fabric.Circle({
        left: 100,
        top: 100,
        radius: 50,
        fill: '#8b5cf6',
        ...options,
      });
      break;
    case 'triangle':
      shapeObj = new fabric.Triangle({
        left: 100,
        top: 100,
        width: 100,
        height: 100,
        fill: '#ec4899',
        ...options,
      });
      break;
    default:
      throw new Error(`Unknown shape: ${shape}`);
  }
  
  canvas.add(shapeObj);
  canvas.setActiveObject(shapeObj);
  canvas.renderAll();
  
  return shapeObj;
}

// Convert canvas to image for export
export function canvasToImage(
  canvas: fabric.Canvas,
  format: 'png' | 'jpeg' = 'png',
  quality: number = 1
): string {
  return canvas.toDataURL({
    format,
    quality,
  });
}

// Apply filters to image objects
export function applyImageFilter(
  canvas: fabric.Canvas,
  object: fabric.Image,
  filter: 'grayscale' | 'sepia' | 'invert' | 'brightness',
  options?: any
): void {
  if (!(object instanceof fabric.Image)) {
    throw new Error('Object is not an image');
  }
  
  // Clear existing filters
  object.filters = [];
  
  // Apply the requested filter
  switch (filter) {
    case 'grayscale':
      object.filters.push(new fabric.Image.filters.Grayscale());
      break;
    case 'sepia':
      object.filters.push(new fabric.Image.filters.Sepia());
      break;
    case 'invert':
      object.filters.push(new fabric.Image.filters.Invert());
      break;
    case 'brightness':
      object.filters.push(new fabric.Image.filters.Brightness({
        brightness: options?.brightness || 0.1,
      }));
      break;
  }
  
  // Apply filters and re-render canvas
  object.applyFilters();
  canvas.renderAll();
}

// Create gradient background
export function createGradientBackground(
  canvas: fabric.Canvas,
  colors: string[],
  direction: 'to-right' | 'to-bottom' | 'to-bottom-right' | 'radial' = 'to-bottom'
): fabric.Object {
  const width = canvas.getWidth();
  const height = canvas.getHeight();
  
  let gradientCoords: {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
  } = { x1: 0, y1: 0, x2: 0, y2: 0 };
  
  switch (direction) {
    case 'to-right':
      gradientCoords = { x1: 0, y1: 0, x2: width, y2: 0 };
      break;
    case 'to-bottom':
      gradientCoords = { x1: 0, y1: 0, x2: 0, y2: height };
      break;
    case 'to-bottom-right':
      gradientCoords = { x1: 0, y1: 0, x2: width, y2: height };
      break;
    default:
      gradientCoords = { x1: 0, y1: 0, x2: 0, y2: height };
  }
  
  let gradient;
  if (direction === 'radial') {
    gradient = new fabric.Gradient({
      type: 'radial',
      coords: {
        r1: 0,
        r2: width > height ? width / 2 : height / 2,
        x1: width / 2,
        y1: height / 2,
        x2: width / 2,
        y2: height / 2,
      },
      colorStops: colors.map((color, index) => ({
        offset: index / (colors.length - 1),
        color,
      })),
    });
  } else {
    gradient = new fabric.Gradient({
      type: 'linear',
      coords: gradientCoords,
      colorStops: colors.map((color, index) => ({
        offset: index / (colors.length - 1),
        color,
      })),
    });
  }
  
  const backgroundRect = new fabric.Rect({
    left: 0,
    top: 0,
    width,
    height,
    fill: gradient,
    selectable: false,
    evented: false,
  });
  
  canvas.add(backgroundRect);
  canvas.sendToBack(backgroundRect);
  canvas.renderAll();
  
  return backgroundRect;
}

// Helper to serialize canvas JSON
export function serializeCanvas(canvas: fabric.Canvas): string {
  return JSON.stringify(canvas.toJSON(['id', 'name']));
}

// Helper to load canvas from JSON
export function loadCanvasFromJSON(
  canvas: fabric.Canvas,
  json: string | object
): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const data = typeof json === 'string' ? JSON.parse(json) : json;
      canvas.loadFromJSON(data, () => {
        canvas.renderAll();
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}
