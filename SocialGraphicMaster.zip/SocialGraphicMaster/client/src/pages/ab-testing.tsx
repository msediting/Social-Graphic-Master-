import { FC, useState, useEffect } from "react";
import { useParams } from "wouter";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { useQuery } from "@tanstack/react-query";
import { ABTest, TestResult } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const ABTestingPage: FC = () => {
  const { id } = useParams();
  const testId = id ? parseInt(id) : undefined;
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("results");
  
  const { data: tests, isLoading: isLoadingTests } = useQuery({
    queryKey: ["/api/ab-tests"],
  });
  
  const { data: test, isLoading: isLoadingTest } = useQuery({
    queryKey: testId ? [`/api/ab-tests/${testId}`] : null,
    enabled: !!testId,
  });
  
  const { data: results, isLoading: isLoadingResults } = useQuery({
    queryKey: testId ? [`/api/ab-tests/${testId}/results`] : null,
    enabled: !!testId,
  });
  
  useEffect(() => {
    // If we have a specific test ID but it fails to load, show an error
    if (testId && !isLoadingTest && !test) {
      toast({
        title: "Test not found",
        description: "The requested A/B test could not be found.",
        variant: "destructive",
      });
    }
  }, [testId, isLoadingTest, test]);
  
  if (!testId && tests && tests.length > 0) {
    // If no specific test is requested, show the dashboard with all tests
    return (
      <div className="h-screen flex flex-col">
        <Header />
        <div className="flex-1 flex overflow-hidden">
          <Sidebar />
          <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
            <h1 className="text-2xl font-bold mb-6">A/B Testing Dashboard</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Tests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {tests.filter((t: ABTest) => t.status === "active").length}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Completed Tests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {tests.filter((t: ABTest) => t.status === "completed").length}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Tests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{tests.length}</div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Recent Tests</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingTests ? (
                  <div className="p-4 text-center">Loading tests...</div>
                ) : (
                  <div className="space-y-2">
                    {tests.map((test: ABTest) => (
                      <div key={test.id} className="flex items-center justify-between p-3 bg-white rounded-md border">
                        <div>
                          <div className="font-medium">{test.name}</div>
                          <div className="text-sm text-gray-500">
                            Created: {format(new Date(test.createdAt), "MMM d, yyyy")}
                          </div>
                        </div>
                        <Button asChild variant="outline" size="sm">
                          <a href={`/ab-testing/${test.id}`}>View Results</a>
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }
  
  // If a specific test is requested, show its details
  return (
    <div className="h-screen flex flex-col">
      <Header />
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />
        <div className="flex-1 overflow-y-auto p-6 bg-gray-50">
          {isLoadingTest || !test ? (
            <div className="flex justify-center items-center h-full">
              {isLoadingTest ? "Loading test data..." : "Test not found"}
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h1 className="text-2xl font-bold">{test.name}</h1>
                  <p className="text-gray-500">
                    Created: {format(new Date(test.createdAt), "MMM d, yyyy")} • 
                    Status: <span className="capitalize">{test.status}</span>
                  </p>
                </div>
                <Button variant="outline" asChild>
                  <a href="/ab-testing">Back to Dashboard</a>
                </Button>
              </div>
              
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="results">Results</TabsTrigger>
                  <TabsTrigger value="designs">Designs</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                </TabsList>
                
                <TabsContent value="results" className="space-y-4 mt-4">
                  {isLoadingResults || !results ? (
                    <div className="flex justify-center items-center h-64">
                      Loading results...
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Impressions A</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">{results.impressionsA}</div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">Impressions B</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">{results.impressionsB}</div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">CTR A</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">
                              {results.impressionsA > 0 
                                ? ((results.clicksA / results.impressionsA) * 100).toFixed(2) 
                                : "0.00"}%
                            </div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium">CTR B</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">
                              {results.impressionsB > 0 
                                ? ((results.clicksB / results.impressionsB) * 100).toFixed(2) 
                                : "0.00"}%
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                      
                      <Card>
                        <CardHeader>
                          <CardTitle>Performance Comparison</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart
                                data={[
                                  {
                                    name: "Impressions",
                                    A: results.impressionsA,
                                    B: results.impressionsB,
                                  },
                                  {
                                    name: "Clicks",
                                    A: results.clicksA,
                                    B: results.clicksB,
                                  },
                                  {
                                    name: "Conversions",
                                    A: results.conversionsA,
                                    B: results.conversionsB,
                                  },
                                ]}
                                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                              >
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="A" fill="#6366F1" name="Version A" />
                                <Bar dataKey="B" fill="#8B5CF6" name="Version B" />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        </CardContent>
                      </Card>
                    </>
                  )}
                </TabsContent>
                
                <TabsContent value="designs" className="space-y-4 mt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Version A</CardTitle>
                      </CardHeader>
                      <CardContent className="flex justify-center">
                        <div className="w-64 h-64 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white font-medium">
                          Design A Preview
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Version B</CardTitle>
                      </CardHeader>
                      <CardContent className="flex justify-center">
                        <div className="w-64 h-64 bg-gradient-to-tr from-blue-500 via-indigo-500 to-purple-500 rounded-lg flex items-center justify-center text-white font-medium">
                          Design B Preview
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
                
                <TabsContent value="settings" className="space-y-4 mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Test Settings</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-1">Test Duration</h4>
                        <p>{test.duration} days</p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">Target Platforms</h4>
                        <div className="flex flex-wrap gap-2">
                          {test.platforms.map((platform: string, index: number) => (
                            <div key={index} className="px-2 py-1 bg-gray-100 rounded-md text-sm capitalize">
                              {platform}
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">Testing Goal</h4>
                        <p className="capitalize">{test.goal}</p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">Weight Distribution</h4>
                        <div className="flex items-center gap-4">
                          <div className="flex-1">
                            <p className="text-sm mb-1">Version A: {test.weightA}%</p>
                            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-indigo-500 rounded-full" 
                                style={{ width: `${test.weightA}%` }}
                              ></div>
                            </div>
                          </div>
                          <div className="flex-1">
                            <p className="text-sm mb-1">Version B: {test.weightB}%</p>
                            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-purple-500 rounded-full" 
                                style={{ width: `${test.weightB}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <div className="flex justify-end gap-2">
                    {test.status === "draft" && (
                      <Button>Start Test</Button>
                    )}
                    {test.status === "active" && (
                      <Button variant="outline">Stop Test</Button>
                    )}
                    <Button variant="destructive">Delete Test</Button>
                  </div>
                </TabsContent>
              </Tabs>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ABTestingPage;
