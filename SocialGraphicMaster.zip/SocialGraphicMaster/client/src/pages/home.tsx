import { FC } from "react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import TemplateGallery from "@/components/TemplateGallery";

const Home: FC = () => {
  return (
    <div className="h-screen flex flex-col">
      <Header />
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />
        <TemplateGallery />
      </div>
    </div>
  );
};

export default Home;
